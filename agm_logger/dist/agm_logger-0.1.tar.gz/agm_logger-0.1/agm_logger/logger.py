import datetime
import sys

import logging


class Logger:

    def __init__(self, filename):
        self.filename = filename

        # Set up logger
        logging.basicConfig(
            filename=filename,
            level=logging.DEBUG,
            format='%(asctime)s %(levelname)s %(name)s %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def log(self, log_type, log_data: str):
        """
        Print the log at the output and write it to the log file
        """
        print(datetime.datetime.now(), log_data)
        if log_type == 'info':
            self.logger.info(log_data)
        elif log_type == 'warn':
            self.logger.warning(log_data)
        elif log_type == 'err':
            self.logger.error(log_data)
        else:
            print(f"Argument 'log_type' has wrong value: {log_type}. Value can be: 'info', 'warn', 'err'.")
            sys.exit()
