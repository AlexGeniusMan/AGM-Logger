from setuptools import setup

setup(name='agm_logger',
      version='0.2',
      description='Custom logger',
      packages=['agm_logger'],
      author_email='alexgeniusman@gmail.com',
      zip_safe=False)
